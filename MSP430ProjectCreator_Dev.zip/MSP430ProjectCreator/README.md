# "MSP430ProjectCreator" is a package which includes several sub-packages and the test package, the upper level is not a package but a directory which has the same name of this package, namely "MSP430ProjectCreator"

# To run the program
# >> python3 MSP430ProjectCreator