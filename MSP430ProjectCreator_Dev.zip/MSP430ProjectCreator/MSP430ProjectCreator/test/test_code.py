import os
import sys
sys.path.append(os.path.abspath(os.path.dirname(__file__) + '/' + '../..'))
# print(os.path.abspath(os.path.dirname(__file__) + '/' + '../..'))
# >> C:\Users\Hang\Desktop\MSP430ProjectCreator
from MSP430ProjectCreator.F2272Project.F2272Project import CreateProjectF2272
from MSP430ProjectCreator.G2553Project.G2553Project import CreateProjectG2553

# need to test the path has no weird characters: C:\MSP430F2272\Src
# need to test the project name has no weird characters: Lab01
proj_1 = CreateProjectF2272("C:\\MSP430F2272\\Lab01")
proj_1.create_project()

proj_2 = CreateProjectG2553("C:\\MSP430G2553\\Lab01")
proj_2.create_project()


#print(proj_2.project_name)
#print(proj_2.project_path)
#print(proj_2.setting_path)
#print(proj_2.debug_path)





