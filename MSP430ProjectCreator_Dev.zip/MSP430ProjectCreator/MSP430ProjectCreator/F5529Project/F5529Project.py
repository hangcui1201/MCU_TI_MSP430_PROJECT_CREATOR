class CreateProjectF5529():

	def __init__(self, project_name):
		self.project_name = project_name